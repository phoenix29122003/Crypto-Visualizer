const firebaseConfig = {
  apiKey: "AIzaSyBMfHUVXe4GDHryY7sJMPmnElS5kLDZZo4",
  authDomain: "crypto-hunter-50991.firebaseapp.com",
  projectId: "crypto-hunter-50991",
  storageBucket: "crypto-hunter-50991.appspot.com",
  messagingSenderId: "141181984273",
  appId: "1:141181984273:web:ba51a25e27ce6a2b1d9bb0",
};

export default firebaseConfig;
